* run: java -jar dubbo-admin-0.1.jar
* modify properties in `application.properties`
