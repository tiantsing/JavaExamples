package com.tiantsing.frist.demoF;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoFApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoFApplication.class, args);
	}

}
